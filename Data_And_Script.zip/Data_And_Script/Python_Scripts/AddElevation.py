import rasterio
import numpy as np        
from osgeo import gdal, ogr
import os

def add_constant_elevation(input_file, output_file, constant_value):
    with rasterio.open(input_file) as src:
        # Read the raster data
        elevation = src.read(1)

        # Get the nodata value
        nodata = src.nodatavals[0]

        # Create a mask for non-background grids
        mask = (elevation != nodata)

        # Add the constant value to non-background grids
        modified_elevation = np.where(mask, elevation + constant_value, elevation)

        # Copy the metadata from the source raster
        meta = src.meta

    # Save the modified raster as a new file
    with rasterio.open(output_file, 'w', **meta) as dst:
        dst.write(modified_elevation, 1)

def generate_contours(dem_tif_path, start_elevation, end_elevation, interval, contour_shp_output):
    # Open the DEM
    dem = gdal.Open(dem_tif_path)
    if dem is None:
        print('Could not open ' + dem_tif_path)
        return

    # Get raster georeference info
    transform = dem.GetGeoTransform()
    xOrigin = transform[0]
    yOrigin = transform[3]
    pixelWidth = transform[1]
    pixelHeight = -transform[5]

    # Create contour dataset
    driver = ogr.GetDriverByName("ESRI Shapefile")
    if os.path.exists(contour_shp_output):
        driver.DeleteDataSource(contour_shp_output)

    outData = driver.CreateDataSource(contour_shp_output)
    if outData is None:
        print('Could not create file ' + contour_shp_output)
        return

    # Create contour layer
    outLayer = outData.CreateLayer("contour", geom_type=ogr.wkbLineString25D)
    field_defn = ogr.FieldDefn("ID", ogr.OFTInteger)
    outLayer.CreateField(field_defn)
    field_defn = ogr.FieldDefn("elev", ogr.OFTReal)
    outLayer.CreateField(field_defn)

    # Generate contour lines
    for level in np.arange(start_elevation, end_elevation, interval):
        print(f'Generating contours for {level} m')
        gdal.ContourGenerate(dem.GetRasterBand(1), level, 0, [], 0, 0, outLayer, 0, 1)
    
    # Close datasets
    outData.Destroy()
    dem = None
