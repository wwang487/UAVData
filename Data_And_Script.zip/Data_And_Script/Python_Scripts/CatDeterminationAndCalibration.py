import psutil
import LengthWidthDepthComputation
import rasterio
from rasterio.enums import Resampling

import rasterio
from rasterio.enums import Resampling

def get_system_info():
    cpu_count = psutil.cpu_count(logical=False)
    ram_gb = round(psutil.virtual_memory().total / (1024.0 ** 3))
    freq_mhz = psutil.cpu_freq().max
    return cpu_count, ram_gb, freq_mhz

def read_total_station_txt_files(file_folder, file_name):
    
    
def get_img_number(img_folder, img_suffix):
    all_files = []
    for file in os.listdir(img_folder):
        file_suffix = file.split('.')[-1]
        if file_suffix == img_suffix:
            all_files.append(file)
    return len(all_files)
    
def get_quality_categories(cpu_count, ram_gb, freq_mhz, img_num):

def get_elevation_error_map():

def compute_mean_hori_error():

def compute_mean_elev_error():

def extract_DEM_with_boundary():

def scale_DEM_using_scale_factor(input_folder, input_file, output_folder, output_file, upscale_factor):
    with rasterio.open(input_folder + input_file) as dataset:

    # resample data to target shape
    data = dataset.read(
        out_shape=(
            dataset.count,
            int(dataset.height * upscale_factor),
            int(dataset.width * upscale_factor)
        ),
        resampling=Resampling.bilinear
    )

    # scale image transform
    transform = dataset.transform * dataset.transform.scale(
        (dataset.width / data.shape[-1]),
        (dataset.height / data.shape[-2])
    )
    
    with rasterio.open(
    output_folder + output_file,
    'w',
    driver = 'GTiff',
    height = int(dataset.height * upscale_factor),
    width = int(dataset.width * upscale_factor),
    count = 1,
    dtype = np.float32,
    transform = transform,
    ) as dest_file:
        dest_file.write(data, 1)
    dest_file.close()
    
def scale_DEM_using_shape():
    
def get_reproj_coefs(x1, y1, x1_prime, y1_prime):
    A = np.array([
    [x1[0], y1[0], 1, 0, 0, 0],
    [0, 0, 0, x1[0], y1[0], 1],
    [x1[1], y1[1], 1, 0, 0, 0],
    [0, 0, 0, x1[1], y1[1], 1],
    [x1[2], y1[2], 1, 0, 0, 0],
    [0, 0, 0, x1[2], y1[2], 1],
    ])

    b = np.array([
        x1_prime[0], y1_prime[0], x1_prime[1],
        y1_prime[1], x1_prime[2], y1_prime[2],
    ])

    # Solve for the coefficients of the linear transformation
    x = np.linalg.solve(A, b)

    # Coefficients of the transformation
    a, b, c, d, e, f = x[0], x[1], x[2], x[3], x[4], x[5]
    return a, b, c, d, e, f
     