# -*- coding: utf-8 -*-
"""
Created on Thu Sep 22 19:47:55 2022

@author: bbean
"""
import cv2
import os
import numpy as np
from osgeo import osr
from FloydSmoothing import FloydSmoothing
from d_start_lite_optimized import DLiteMain
from osgeo import gdal

def CheckIfFolderExist(filepath):
    if os.path.exists(f'{filepath}'):
        pass
    else:
        os.mkdir(f'{filepath}') 
        
#%% This cell deals with geographic system coversion.
def getSRSPair(dataset):
    prosrs = osr.SpatialReference()
    prosrs.ImportFromWkt(dataset.GetProjection())
    geosrs = prosrs.CloneGeogCS()
    return prosrs, geosrs
 
def geo2lonlat(dataset, x, y):
    prosrs, geosrs = getSRSPair(dataset)
    ct = osr.CoordinateTransformation(prosrs, geosrs)
    coords = ct.TransformPoint(x, y)
    return coords[:2]
 
 
def lonlat2geo(dataset, lon, lat):
    prosrs, geosrs = getSRSPair(dataset)
    ct = osr.CoordinateTransformation(geosrs, prosrs)
    coords = ct.TransformPoint(lon, lat)
    return coords[:2]
 
def imagexy2geo(dataset, row, col):
    trans = dataset.GetGeoTransform()
    px = trans[0] + col * trans[1] + row * trans[2]
    py = trans[3] + col * trans[4] + row * trans[5]
    return px, py
 
 
def geo2imagexy(dataset, x, y):
    trans = dataset.GetGeoTransform()
    a = np.array([[trans[1], trans[2]], [trans[4], trans[5]]])
    b = np.array([x - trans[0], y - trans[3]])
    return np.linalg.solve(a, b) 

def get_tif_info(tif_path):
    if tif_path.endswith('.tif') or tif_path.endswith('.TIF'):
        dataset = gdal.Open(tif_path)
        pcs = osr.SpatialReference()
        pcs.ImportFromWkt(dataset.GetProjection())
        gcs = pcs.CloneGeogCS()
        extend = dataset.GetGeoTransform()
        # im_width = dataset.RasterXSize #栅格矩阵的列数
        # im_height = dataset.RasterYSize #栅格矩阵的行数
        shape = (dataset.RasterYSize, dataset.RasterXSize)
    else:
        raise "Unsupported file format"

    img = dataset.GetRasterBand(1).ReadAsArray()  # (height, width)
    # img(ndarray), gdal数据集、地理空间坐标系、投影坐标系、栅格影像大小
    return img, dataset, gcs, pcs, extend, shape

def longlat_to_xy(gcs, pcs, lon, lat):
    ct = osr.CoordinateTransformation(gcs, pcs)
    coordinates = ct.TransformPoint(lon, lat)
    return coordinates[0], coordinates[1], coordinates[2]


def xy_to_lonlat(gcs, pcs, x, y):
    ct = osr.CoordinateTransformation(gcs, pcs)
    lon, lat, _ = ct.TransformPoint(x, y)
    return lon, lat


def xy_to_rowcol(extend, x, y):
    a = np.array([[extend[1], extend[2]], [extend[4], extend[5]]])
    b = np.array([x - extend[0], y - extend[3]])

    row_col = np.linalg.solve(a, b)
    row = int(np.floor(row_col[1]))
    col = int(np.floor(row_col[0]))

    return row, col


def rowcol_to_xy(extend, row, col):
    x = extend[0] + col * extend[1] + row * extend[2]
    y = extend[3] + col * extend[4] + row * extend[5]
    return x, y

def get_value_by_coordinates(img, dataset, gcs, pcs, extend, shape, coordinates, coordinate_type='rowcol'):

    if coordinate_type == 'rowcol':
        value = img[coordinates[0], coordinates[1]]
    elif coordinate_type == 'lonlat':
        x, y, _ = longlat_to_xy(gcs, pcs, coordinates[0], coordinates[1])
        row, col = xy_to_rowcol(extend, x, y)
        value = img[row, col]
    elif coordinate_type == 'xy':
        row, col = xy_to_rowcol(extend, coordinates[0], coordinates[1])
        value = img[row, col]
    else:
        raise 'coordinated_type error'
    return value

def adjustPointCoordsWithTopLetPoint(point_x, point_y, tl_x, tl_y):
    return point_x - tl_x, point_y - tl_y

def adjustPointListCoordsWithTopLeftPoint(point_x_list, point_y_list, tl_x, tl_y):
    res_x, res_y = [], []
    for i in range(len(point_x_list)):
        temp_x, temp_y = adjustPointCoordsWithTopLetPoint(point_x_list[i], \
                                                point_y_list[i], tl_x, tl_y)
        res_x.append(temp_x)
        res_y.append(temp_y)
    return res_x, res_y

#%% This cell deal with zig-zag nodes computation

#%% This cell deals with map creation
def createEmptyImg(row_num, col_num):
    return np.zeros((row_num, col_num))

def generateBWImg(boundary_x_list, boundary_y_list, tl_x, tl_y, tif_path):
    img, dataset, gcs, pcs, extend, shape = get_tif_info(tif_path)
    
    