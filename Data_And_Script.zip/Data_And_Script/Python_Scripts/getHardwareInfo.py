import psutil
import torch

def get_system_info():
    # Get CPU core count
    physical_cores = psutil.cpu_count(logical=False)
    logical_cores = psutil.cpu_count(logical=True)

    # Get CPU frequency
    freq = psutil.cpu_freq()

    # Get memory info
    mem = psutil.virtual_memory()

    # Print CPU and Memory Information
    print(f"Physical Cores: {physical_cores}")
    print(f"Logical Cores: {logical_cores}")
    print(f"CPU Frequency: {freq.current:.2f} MHz")
    print(f"Total Memory: {mem.total / (1024 ** 3):.2f} GB")
    print(f"Available Memory: {mem.available / (1024 ** 3):.2f} GB")

    # Check for GPU
    if torch.cuda.is_available():
        num_gpus = torch.cuda.device_count()
        print(f"Number of GPUs: {num_gpus}")
        for i in range(num_gpus):
            device = torch.cuda.get_device_name(i)
            cuda_cores = torch.cuda.get_device_properties(i).multi_processor_count * 64  # Approximate CUDA core count
            print(f"GPU {i + 1}: {device}")
            print(f"CUDA Cores: {cuda_cores}")
    else:
        num_gpus, cuda_cores = 0, 0
        print("No independent GPU detected.")
    return physical_cores, logical_cores, freq.current, mem.total, mem.available, num_gpus, cuda_cores